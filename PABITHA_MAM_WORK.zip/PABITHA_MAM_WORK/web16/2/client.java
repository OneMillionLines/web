import java.rmi.*;
import java.rmi.registry.*;  
public class client{
public static void main(String args[])
{
try{
Adder stub=(Adder)Naming.lookup("rmi://localhost:8888/3046");
System.out.println(stub.add(3,4));
}
catch(Exception e){System.out.println(e);}  
}
}

