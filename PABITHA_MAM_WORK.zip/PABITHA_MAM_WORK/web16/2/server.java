import java.rmi.*;  
import java.rmi.registry.*;  
public class server{  
public static void main(String args[]){  
try{  
Adder stub=new AdderRemote();  
Naming.rebind("rmi://localhost:8888/3046",stub);  
}catch(Exception e){System.out.println(e);}  
}  
}  

