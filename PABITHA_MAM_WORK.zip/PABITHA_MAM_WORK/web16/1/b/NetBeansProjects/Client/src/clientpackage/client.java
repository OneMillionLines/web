/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientpackage;
import java.net.*;
import java.util.*;
import java.io.*;
/**
 *
 * @author student
 */
public class client
{
	public static void main(String[] argv) throws Exception
	{
		InetAddress ip=InetAddress.getLocalHost();
		Socket s=new Socket(ip.getHostAddress(),2908);
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		DataInputStream dis=new DataInputStream(s.getInputStream());
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter ## to transfer files\n");		
		while(true){
			System.out.print("Enter Your Message: ");
			String str1=sc.nextLine();
			if(str1.equals("##")){
				FileClient fc = new FileClient("localhost", 1988, "/home/student/ns3/ns-allinone-3.19/ns-3.19/utils/rescale-pdf.sh");
			}
			dos.writeUTF(str1);
			String str2=(String)dis.readUTF();
			System.out.println("Message from Server : "+str2);
		}
		//dis.close();
		//dos.close();
		//s.close();
	}
}