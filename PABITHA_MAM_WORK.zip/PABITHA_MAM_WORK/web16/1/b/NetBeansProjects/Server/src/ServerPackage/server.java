/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerPackage;

/**
 *
 * @author student
 */
import java.net.*;
import java.io.*;
import java.util.*;

public class server
{
	public static void main(String[] argv)
	{
	try{
		FileServer fs = new FileServer(1988);
		fs.start();
		ServerSocket ss=new ServerSocket(2908);
		Socket s=ss.accept();
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		DataInputStream dis=new DataInputStream(s.getInputStream());
		Scanner sc=new Scanner(System.in);
		//String str1=sc.nextLine();
		while(true){
		String str2=(String)dis.readUTF();
		System.out.println("Message from Client : "+str2);
		System.out.print("Enter Your Message: ");
		String str1=sc.nextLine();
		dos.writeUTF(str1);}}
		//dis.close();
		catch(Exception e){e.printStackTrace();}
		//dos.close();
		//s.close();
		//ss.close();
	}
}
