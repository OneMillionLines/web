import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
public class Client
{
   public static void main(String[] first)
   {
      try{
      
      Adder s=(Adder)Naming.lookup("rmi://localhost:8787/sonoo");
      System.out.println(s.add(199,2));
      System.out.println(s.pri("sample.txt"));
      //System.out.println("38");
      
      }
      catch(Exception e)
      {
        System.out.println(e);
      }
   }
}


