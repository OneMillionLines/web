import java.util.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
public class Adderimp extends UnicastRemoteObject implements Adder 
{
    public Adderimp() throws RemoteException
    {super();}
    public int add(int a,int b)throws RemoteException
    {
      return a+b;
    }
    public String pri(String str)throws Exception
    {
     // System.out.println(str);
      FileReader fi=new FileReader(str);
      BufferedReader br=new BufferedReader(fi);
      String b;
      /*while((br=(String)fi.readLine())!=null)
      {
        System.out.println(br);
      }*/
      if(br!=null)
      {

        while((b=(String)br.readLine())!=null)
      {
        System.out.println(b);
      }
              return "File successfully accepted";
        }
     else
       return "File Not found";
    }
  
}
