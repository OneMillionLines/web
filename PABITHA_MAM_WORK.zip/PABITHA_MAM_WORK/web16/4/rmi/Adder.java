import java.io.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
public interface Adder extends Remote
{
   public int add(int a,int b)throws RemoteException;
   public String pri(String str)throws Exception;
}
