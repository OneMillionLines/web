import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
public class Server
{
	public static void main(String[] first)
	{
	    try{
	      Adder st=new Adderimp();
	      Naming.rebind("rmi://localhost:8787/sonoo",st);
	    }
	    catch(Exception e){System.out.println(e);}
	}
}
